package com.example.cs360project3option2benwalla;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

import javax.security.auth.Subject;

public class UserDatabase extends SQLiteOpenHelper {

    private static final String name = "eventplanner.db";
    private static final int version = 1;
    public enum SubjectSortOrder { ALPHABETIC, UPDATE_DESC, UPDATE_ASC };

    public UserDatabase(Context context) {
        super(context, name, null, version);
    }

    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String col_id =  "_id";
        private static final String col_user = "username";
        private static final String col_pass = "password";
    }

    private static final class EventTable {
        private static final String TABLE = "events";
        private static final String col_id = "_id";
        private static final String col_title = "title";
        private static final String col_date = "date";
        private static final String col_desc = "description";
    }

    private static final class NotificationsTable {
        private static final String TABLE = "notifications";
        private static final String col_id = "_id";
        private static final String col_not = "notifications";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + UserTable.TABLE + EventTable.TABLE + NotificationsTable.TABLE + " (" +
                UserTable.col_id + " integer primary key autoincrement, " +
                EventTable.col_id + " integer primary key autoincrement, " +
                NotificationsTable.col_id + " integer primary key autoincrement, " +
                UserTable.col_user + " text, " +
                UserTable.col_pass + " text, " +
                EventTable.col_title + " text, " +
                EventTable.col_date + " text, " +
                EventTable.col_desc + " text, " +
                NotificationsTable.col_not + " text)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + UserTable.TABLE + EventTable.TABLE + NotificationsTable.TABLE);
        onCreate(db);
    }

    public boolean addUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.col_user, user.getUsername());
        values.put(UserTable.col_pass, user.getPassword());
        long id = db.insert(UserTable.TABLE, null, values);
        return id != -1;
    }

    public void updateUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UserTable.col_user, user.getUsername());
        values.put(UserTable.col_pass, user.getPassword());
        db.update(UserTable.TABLE, values,
                UserTable.col_id +" = ?", new String[] { user.getId()});
    }

    public void deleteUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(UserTable.TABLE,
                UserTable.col_id + " = ?", new String[] { user.getId() });
    }

    public boolean addEvent(Event event) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventTable.col_title, event.getTitle());
        values.put(EventTable.col_date, event.getDate());
        values.put(EventTable.col_date, event.getDesc());
        long id = db.insert(EventTable.TABLE, null, values);
        return id != -1;
    }

    public void updateSubject(Event event) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(EventTable.col_title, event.getTitle());
        values.put(EventTable.col_date, event.getDate());
        values.put(EventTable.col_desc, event.getDesc());
        db.update(EventTable.TABLE, values,
                EventTable.col_id + " = ?", new String[] { event.getId() });
    }

    public void deleteSubject(Event event) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(EventTable.TABLE,
                EventTable.col_id + " = ?", new String[] { event.getId() });
    }
}
