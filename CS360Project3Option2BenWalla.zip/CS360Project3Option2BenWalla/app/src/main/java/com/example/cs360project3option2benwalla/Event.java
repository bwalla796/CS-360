package com.example.cs360project3option2benwalla;

public class Event {
    private String mTitle;
    private String mDate;
    private String mDesc;
    private String mId;

    public Event() {}

    public Event(String title, String date, String desc) {
        mTitle = title;
        mDate = date;
        mDesc = desc;
    }

    public String getTitle() {
        return mTitle;
    }

    public void setTitle(String title) {
        mTitle = title;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date) {
        mDate = date;
    }

    public String getDesc() {
        return mDesc;
    }

    public void setDesc(String desc) {
        mDesc = desc;
    }

    public String getId() {
        return mId;
    }

    public void setId(String id) {
        mId = id;
    }
}

