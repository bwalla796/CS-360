package com.example.cs360project3option2benwalla;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;


public class NotificationsActivity extends AppCompatActivity {

    private final int SMS_PERMISSION_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        //Creates button objects
        Button button = findViewById(R.id.back_button);
        Button buttonNot = findViewById(R.id.sms_notifications_button);

        //Enables buttons to do something on click
        button.setOnClickListener(view -> openHomeDisplay());
        buttonNot.setOnClickListener(view -> {
            if (ContextCompat.checkSelfPermission(NotificationsActivity.this,
                    Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(NotificationsActivity.this, "You have already granted this permission!", Toast.LENGTH_SHORT).show();
            } else {
                requestSmsPermission();
            }
        });
    }
    //Back button intent function
    public void openHomeDisplay() {
        Intent intent = new Intent(this, HomeDisplay.class);
        startActivity(intent);
    }
    //SMS permissions function
    private void requestSmsPermission() {
        if(ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_SMS)&& ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECEIVE_SMS)) {

            new AlertDialog.Builder(this)
                    .setTitle("Permission Needed")
                    .setMessage("This permission is needed for SMS Notifications")
                    .setPositiveButton("Okay", (dialogInterface, i) -> ActivityCompat.requestPermissions(NotificationsActivity.this, new String[] {Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, SMS_PERMISSION_CODE))
                    .setNegativeButton("Cancel", (dialogInterface, i) -> dialogInterface.dismiss())
                    .create().show();

        } else {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_SMS, Manifest.permission.RECEIVE_SMS}, SMS_PERMISSION_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission GRANTED", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }
}