package com.example.cs360project3option2benwalla;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //Creates text view and button objects
        TextView username = findViewById(R.id.username);
        TextView password = findViewById(R.id.password);

        Button button = findViewById(R.id.submit_button);

        //Enables button to authenticate username and password and switch to HomeDisplay screen.
        //Username and Pass: admin
        button.setOnClickListener(view -> {
            if (username.getText().toString().equals("admin") && password.getText().toString().equals("admin")) {
                //Correct
                Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
                openHomeDisplay();
            } else {
                //Incorrect
                Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
            }
        });

    }
    public void openHomeDisplay() {
        Intent intent = new Intent(this, HomeDisplay.class);
        startActivity(intent);
    }
}