package com.example.cs360project3option2benwalla;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class HomeDisplay extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_display);

        //Creates text view and button object
        Button button1 = findViewById(R.id.button_settings);
        Button button2 = findViewById(R.id.button_logout);

        //Enables button to do something on click
        button1.setOnClickListener(view -> openNotificationsActivity());
        button2.setOnClickListener(view -> openMainActivity());
    }
    public void openNotificationsActivity() {
        Intent intent = new Intent(this, NotificationsActivity.class);
        startActivity(intent);
    }
    public void openMainActivity() {
        Intent intent2 = new Intent(this, MainActivity.class);
        startActivity(intent2);
    }
}